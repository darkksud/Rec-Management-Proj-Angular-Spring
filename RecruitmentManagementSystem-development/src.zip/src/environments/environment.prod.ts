export const environment = {
  production: true,
  backGroundUrl: 'http://localhost:8081/'
};
